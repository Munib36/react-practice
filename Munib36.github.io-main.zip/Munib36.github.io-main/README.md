# SALAMU 3ALYKUM WA RA7MATUL LAHI WA BARAKATU

## Repositories
- [Overview Of Projects](# Overview of Projects)

- [Detailed Overviews](# Detailed Overviews)
  - [My Travel journal](https://munib.netlify.app)
  - [Saddam Hussein](https://munib36.github.io/aug2023/saddam.html)
  - [Biosys](https://munib36.github.io/aug2023/Biosys)
 
   ![!](./mytraveljournal/public/Screenshot.png)
  
