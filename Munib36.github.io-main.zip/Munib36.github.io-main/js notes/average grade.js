let grades = [20, 0, 19, 17]
let total = 0;

for(let i = 0; i < grades.length; i++){
    total += grades[i];
}
console.log(total / grades.length) 